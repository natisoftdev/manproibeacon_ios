//
//  PlayVC.swift
//  ManPro.net
//
//  Created by Lorenzo Malferrari on 27/03/19.
//  Copyright © 2019 Natisoft. All rights reserved.
//

/*import UIKit

class PlayVC: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}*/
